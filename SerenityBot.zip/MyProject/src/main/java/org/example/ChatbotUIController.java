package org.example;

import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;
import org.alicebot.ab.MagicBooleans;

import static org.example.Chatbot.*;

public class ChatbotUIController {

    public TextField userInput;
    public TextArea chatHistory;
    private Chat chatSession;


    public void initialize(){
        MagicBooleans.trace_mode = TRACE_MODE;
        String resourcesPath = getResourcesPath();
        Bot bot = new Bot(botName, resourcesPath);
        chatHistory.setEditable(false);
        chatSession = new Chat(bot);
    }

    public void sendMessageOnAction(MouseEvent mouseEvent) {
        sendMessage();
    }
    private void sendMessage() {
        String userMessage = userInput.getText();
        displayUserMessage(userMessage);
        String botResponse = chatSession.multisentenceRespond(userMessage);
        displayBotResponse(botResponse);
        userInput.clear();
    }
    private void displayUserMessage(String message) {
        chatHistory.appendText("You: " + message + "\n");
    }

    private void displayBotResponse(String message) {
        chatHistory.appendText("Serenity: " + message + "\n");
    }

    public void setOnAction(ActionEvent actionEvent) {
        sendMessage();
    }
}
