package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;
import org.alicebot.ab.MagicBooleans;

import java.io.File;

public class Main extends Application {
    private static final boolean TRACE_MODE = false;
    static String botName = "super";
    private Chat chatSession;
    private TextArea chatHistory;
    private TextField userInput;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            String resourcesPath = getResourcesPath();
            MagicBooleans.trace_mode = TRACE_MODE;
            Bot bot = new Bot(botName, resourcesPath);
            chatSession = new Chat(bot);

            primaryStage.setTitle("Chatbot UI");

            chatHistory = new TextArea();
            chatHistory.setEditable(false);

            userInput = new TextField();
            userInput.setOnAction(event -> sendMessage());

            Button sendButton = new Button("Send");
            sendButton.setOnAction(event -> sendMessage());

            Button clearButton = new Button("Clear");
            clearButton.setOnAction(event -> clearMessage());

            HBox buttonBox = new HBox(sendButton, clearButton);
            VBox vBox = new VBox(chatHistory, userInput, buttonBox);
            Scene scene = new Scene(vBox, 400, 400);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getResourcesPath() {
        File currDir = new File(".");
        String path = currDir.getAbsolutePath();
        path = path.substring(0, path.length() - 2);
        String resourcesPath = path + File.separator + "src" + File.separator + "main" + File.separator + "resources";
        return resourcesPath;
    }

    private void sendMessage() {
        String userMessage = userInput.getText();
        displayUserMessage(userMessage);
        String botResponse = chatSession.multisentenceRespond(userMessage);
        displayBotResponse(botResponse);
        userInput.clear();
    }

    private void clearMessage() {
        userInput.clear();
    }

    private void displayUserMessage(String message) {
        chatHistory.appendText("You: " + message + "\n");
    }

    private void displayBotResponse(String message) {
        chatHistory.appendText("Serenity: " + message + "\n");
    }
}
